import os
try:
    from time import sleep
except ModuleNotFoundError:
    os.system('pip3 install time')
while True:
    '<'+'='*5+'>'
    sleep(5.0)
